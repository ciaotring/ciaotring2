## 写在前面

node程序中存在大量的异步操作，错误处理也是个老大难的事情。TODO

## 相关链接

Best Practices for Error Handling in Node.js
http://www.joyent.com/developers/node/design/errors

Rich JavaScript errors
https://github.com/joyent/node-verror

