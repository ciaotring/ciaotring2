## 相关链接

How to get a performance boost using Node.js native addons
https://medium.com/developers-writing/how-to-get-a-performance-boost-using-node-js-native-addons-fd3a24719c85#.vgvaqdevt