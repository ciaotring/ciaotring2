// flowing + paused
