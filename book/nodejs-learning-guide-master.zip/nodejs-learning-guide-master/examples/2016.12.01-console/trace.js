console.trace('trace is called');

// Trace: trace is called
//     at Object.<anonymous> (/Users/a/Documents/git-code/nodejs-learning-guide/examples/2016.12.01-console/trace.js:1:71)
//     at Module._compile (module.js:541:32)
//     at Object.Module._extensions..js (module.js:550:10)
//     at Module.load (module.js:456:32)
//     at tryModuleLoad (module.js:415:12)
//     at Function.Module._load (module.js:407:3)
//     at Function.Module.runMain (module.js:575:10)
//     at startup (node.js:160:18)
//     at node.js:445:3