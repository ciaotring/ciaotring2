try{
	console.assert(false, 'error occurred');
}catch(e){
	console.log(e.message);
}