console.assert(true, '1、right');
console.assert(false, '2、right', '2、wrong');