var timeLabel = 'hello;'

console.time(timeLabel);

setTimeout(console.timeEnd, 1000, timeLabel);