const addon = require('./build/Release/addon.node');
console.log( addon.hello() );