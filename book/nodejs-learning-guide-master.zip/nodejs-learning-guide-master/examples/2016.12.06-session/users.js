module.exports = {
	items: [
		{name: 'chyingp', password: '123456'}
	]
};