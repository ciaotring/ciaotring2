console.log( 'process.connected: ' + process.connected );
console.log( process.channel );
process.disconnect();

console.log( 'process.connected: ' + process.connected );