// node argv.js --debug hello age=12
/*
	0: node
	1: /Users/a/Documents/git-code/git-blog/demo/2015.05.21-node-basic/process/argv.js
	2: --debug
	3: hello
	4: age=12
 */
console.log(process.execPath);