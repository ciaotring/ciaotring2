if(process.env.NODE_ENV === 'production'){
	console.log('生产环境');
}else{
	console.log('非生产环境');
}