console.log('海贼王');
process.nextTick(function(){
	console.log('火影忍者');
});
console.log('死神');