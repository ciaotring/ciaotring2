// process.on('exit', function(code){
// 	console.log('process exits with code: ' + code);
// });

process.exit(1);

console.log('hello');