var crypto = require('crypto');

var alice = crypto.createDiffieHellman();